const config = require('bedrock').config;

// mongodb config
config.mongodb.name = 'mongo_lambda';
config.mongodb.host = '172.31.74.172';
